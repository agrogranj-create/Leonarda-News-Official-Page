LEONARDA NEWS — SEPTIEMBRE / OCTUBRE / NOVIEMBRE 2026

El archivo index.html está directamente en la raíz del ZIP.
Para GitHub Pages: extraé/subí index.html a la raíz del repositorio y publicá la rama correspondiente.
La versión es autónoma: imágenes, estilos, JavaScript y audio están integrados en index.html.
